DESERT JOB - ÇEVRİMDIŞI ANDROID UYGULAMASI

Bu proje, yüklediğin DesertJob HTML oyununu tarayıcı adres çubuğu olmadan,
tam ekran bir Android uygulamasının içine yerleştirir.

ÖNEMLİ:
- Oyun HTML dosyası APK'nın içine konur.
- Three.js, APK derlenirken indirilip uygulama dosyalarının içine eklenir.
- Kurulan oyun Three.js veya Google Fonts için internete ihtiyaç duymaz.
- Google Fonts bağlantıları kaldırıldı; cihazın yerel yazı tipleri kullanılır.
- Oyunun kayıtları WebView localStorage alanında cihazda saklanır.
- Oyun içindeki mevcut grafikler, kontroller ve kayıt mantığı korunmuştur.
- Bu bir WebView tabanlı Android uygulamasıdır; oyunun motoru baştan native olarak yazılmamıştır.

APK OLUŞTURMA (BİLGİSAYAR GEREKTİRMEDEN, GITHUB ÜZERİNDEN):
1. GitHub'da yeni, boş bir repository oluştur.
2. Bu ZIP'i açıp içindeki dosya ve klasörleri repository'ye yükle.
3. Repository'de Actions sekmesini aç.
4. "Build Desert Job APK" iş akışının tamamlanmasını bekle.
5. Tamamlanan çalışmanın Artifacts bölümünden "DesertJob-debug-APK" dosyasını indir.
6. ZIP'i aç. İçindeki app-debug.apk Android cihaza kurulabilir test APK'sıdır.

NOT:
- İlk derleme sırasında Gradle bağımlılıkları ve Three.js indirilirken internet gerekir.
- APK kurulduktan sonra oyun yerel dosyalardan açılır; oyun çalışırken internet gerekmez.
- Debug APK kişisel test içindir. Play Store yayını için ayrıca imzalama ve mağaza gereklilikleri vardır.
- Bu proje henüz derlenmiş APK değildir; APK GitHub Actions derlemesiyle üretilecektir.
